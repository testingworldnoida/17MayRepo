package fetchdata;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class CSVDataReader {

	public int findNumberOfRows(String filePath) throws Exception{
		int count = 0 ;
	    File f  = new File(filePath);
	    FileReader fr = new FileReader(f);
	    BufferedReader br = new BufferedReader(fr);
	    String s = br.readLine();
	    while(s!=null){
	    	count =  count +1 ;
	    	s = br.readLine();
	    }
	    return count-1;
	}
	
	public String findCompleteRow(String filePath, int rowNumber) throws Exception{
		int count = 0 ;
		String result = "";
	    File f  = new File(filePath);
	    FileReader fr = new FileReader(f);
	    BufferedReader br = new BufferedReader(fr);
	    String s = br.readLine();
	    while(s!=null){
	    	count =  count +1 ;
	    	if(count ==   rowNumber){
	    		result = s;
	    		break;
	    	}
	    	s = br.readLine();
	    }
	    return result;
	}
	
	public String findCellData(String filePath, int rowNumber, int cellNumber) throws Exception{
		int count = 0 ;
		String result = "";
	    File f  = new File(filePath);
	    FileReader fr = new FileReader(f);
	    BufferedReader br = new BufferedReader(fr);
	    String s = br.readLine();
	    while(s!=null){
	    	count =  count +1 ;
	    	if(count ==   rowNumber){
	    		result = s.split(",")[cellNumber-1];
	    		break;
	    	}
	    	s = br.readLine();
	    }
	    return result;
	}
	
	
	
}
